#!/bin/bash
echo "🍎 QuirkLog 安装程序"
echo "=================="

echo "📦 正在安装 QuirkLog..."

# 创建程序目录
INSTALL_DIR="$HOME/QuirkLog"
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
fi
mkdir -p "$INSTALL_DIR"

# 复制文件
cp QuirkLog "$INSTALL_DIR/"
cp *.html "$INSTALL_DIR/" 2>/dev/null || true
cp *.css "$INSTALL_DIR/" 2>/dev/null || true
cp *.js "$INSTALL_DIR/" 2>/dev/null || true
cp *.xml "$INSTALL_DIR/" 2>/dev/null || true

# 设置执行权限
chmod +x "$INSTALL_DIR/QuirkLog"

# 创建启动脚本
echo '#!/bin/bash' > "$HOME/Desktop/QuirkLog.command"
echo "cd '$INSTALL_DIR'" >> "$HOME/Desktop/QuirkLog.command"
echo "./QuirkLog" >> "$HOME/Desktop/QuirkLog.command"
chmod +x "$HOME/Desktop/QuirkLog.command"

echo "✅ 安装完成！桌面已创建启动脚本"
