# QuirkLog v1.0.0

## 安装说明

### Windows
1. 双击运行 install.bat
2. 按提示完成安装
3. 双击桌面上的 QuirkLog 快捷方式启动

### Mac/Linux
1. 在终端中运行: chmod +x install.sh && ./install.sh
2. 双击桌面上的 QuirkLog.command 启动

## 使用说明
- 支持Web和GUI两种界面模式
- 首次启动会自动选择最适合的模式
- 数据保存在用户目录的daylog文件夹中

构建时间: 2025-08-19 17:01:53
构建平台: Darwin arm64
